// Build step: reads the READABLE source (src/index.html), scrambles its <script> TWICE,
// and writes the result to public/index.html, which is what visitors actually get.
// Runs automatically on Vercel (see "buildCommand" in vercel.json) or locally: npm run build
const fs = require("fs");
const path = require("path");
const JavaScriptObfuscator = require("javascript-obfuscator");

const SRC = path.join(__dirname, "..", "src", "index.html");
const OUT = path.join(__dirname, "..", "public", "index.html");

const html = fs.readFileSync(SRC, "utf8");
const re = /<script>([\s\S]*?)<\/script>/;
const match = html.match(re);
if (!match) throw new Error("No inline <script> found in src/index.html");

// Pass 1: structure scrambling (control flow, dead code, base64 string table)
const pass1 = JavaScriptObfuscator.obfuscate(match[1], {
  compact: true,
  controlFlowFlattening: true,
  controlFlowFlatteningThreshold: 0.6,
  deadCodeInjection: true,
  deadCodeInjectionThreshold: 0.2,
  identifierNamesGenerator: "hexadecimal",
  stringArray: true,
  stringArrayEncoding: ["base64"],
  stringArrayThreshold: 0.8,
  splitStrings: true,
  splitStringsChunkLength: 6,
  numbersToExpressions: true,
  simplify: true,
}).getObfuscatedCode();

// Pass 2: wrap the already-scrambled code again with a different string encoding (RC4)
const pass2 = JavaScriptObfuscator.obfuscate(pass1, {
  compact: true,
  identifierNamesGenerator: "mangled-shuffled",
  stringArray: true,
  stringArrayEncoding: ["rc4"],
  stringArrayThreshold: 1,
  stringArrayRotate: true,
  stringArrayShuffle: true,
  stringArrayWrappersCount: 3,
  stringArrayWrappersType: "function",
  splitStrings: true,
  splitStringsChunkLength: 5,
}).getObfuscatedCode();

// Use a function so "$" characters in the code are never treated as replacement patterns,
// and make sure the code can't accidentally close the <script> tag.
const safe = pass2.replace(/<\/script/gi, "<\\/script");
const out = html.replace(re, () => "<script>" + safe + "</script>");

fs.mkdirSync(path.dirname(OUT), { recursive: true });
fs.writeFileSync(OUT, out);
console.log(`Obfuscated twice: ${match[1].length} -> ${safe.length} chars. Wrote public/index.html`);
